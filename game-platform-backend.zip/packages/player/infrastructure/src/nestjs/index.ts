export { createNestPlayerModule } from './module';
