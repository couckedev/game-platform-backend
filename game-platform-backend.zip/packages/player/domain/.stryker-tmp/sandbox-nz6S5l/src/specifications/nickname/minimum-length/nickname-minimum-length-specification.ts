// @ts-nocheck
export function satisfiesNicknameMinimumLength() {}