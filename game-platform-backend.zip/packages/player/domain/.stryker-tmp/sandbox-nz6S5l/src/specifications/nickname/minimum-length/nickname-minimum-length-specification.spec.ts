// @ts-nocheck
import { describe, expect, it } from 'vitest';
import { satisfiesNicknameMinimumLength } from './nickname-minimum-length-specification';

describe(satisfiesNicknameMinimumLength, () => {
  it('satisfies if nickname is 5 character length', () => {
    const nickname = '12345';

    const isSatisfied = satisfiesNicknameMinimumLength(nickname);

    expect(isSatisfied).toBeTruthy();
  });
});
