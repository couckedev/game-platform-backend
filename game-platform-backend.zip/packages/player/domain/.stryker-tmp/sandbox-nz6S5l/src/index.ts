// @ts-nocheck
export default {};