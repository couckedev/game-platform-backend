// @ts-nocheck
import { describe, expect, it } from 'vitest';
import {
  NicknameTooFewLettersError,
  NicknameTooLongError,
  NicknameTooShortError,
} from '../../errors/nickname';
import { Nickname } from './nickname';

describe(Nickname, () => {
  it('creates nickname object if nickname is 5 characters long', () => {
    const nicknameValue = 'abc45';

    const nickname = Nickname.create(nicknameValue);

    expect(nickname.value).toStrictEqual(nicknameValue);
  });
  it('creates nickname object if nickname is 6 characters long', () => {
    const nicknameValue = 'abc456';

    const nickname = Nickname.create(nicknameValue);

    expect(nickname.value).toStrictEqual(nicknameValue);
  });
  it('fails to create nickname object if nickname is 4 characters long', () => {
    const nicknameValue = '1234';

    const nicknameCreation = () => Nickname.create(nicknameValue);

    expect(nicknameCreation).toThrow(new NicknameTooShortError(nicknameValue));
  });
  it('fails to create nickname object if nickname is 3 characters long', () => {
    const nicknameValue = '123';

    const nicknameCreation = () => Nickname.create(nicknameValue);

    expect(nicknameCreation).toThrow(new NicknameTooShortError(nicknameValue));
  });
  it('creates nickname object if nickname is 20 characters long', () => {
    const nicknameValue = 'abc34567890123456abc';

    const nickname = Nickname.create(nicknameValue);

    expect(nickname.value).toStrictEqual(nicknameValue);
  });
  it('fails to create nickname object if nickname is 21 characters long', () => {
    const nicknameValue = '012345678901234567890';

    const nicknameCreation = () => Nickname.create(nicknameValue);

    expect(nicknameCreation).toThrow(new NicknameTooLongError(nicknameValue));
  });
  it('fails to create nickname object if nickname is 22 characters long', () => {
    const nicknameValue = '0123456789012345678901';

    const nicknameCreation = () => Nickname.create(nicknameValue);

    expect(nicknameCreation).toThrow(new NicknameTooLongError(nicknameValue));
  });
  it('fails to create nickname object if nickname does not contain 3 letters at least', () => {
    const nicknameValue = '123456789';

    const nicknameCreation = () => Nickname.create(nicknameValue);

    expect(nicknameCreation).toThrow(
      new NicknameTooFewLettersError(nicknameValue),
    );
  });
});
