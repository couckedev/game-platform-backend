// @ts-nocheck
function stryNS_9fa48() {
  var g = typeof globalThis === 'object' && globalThis && globalThis.Math === Math && globalThis || new Function("return this")();
  var ns = g.__stryker__ || (g.__stryker__ = {});
  if (ns.activeMutant === undefined && g.process && g.process.env && g.process.env.__STRYKER_ACTIVE_MUTANT__) {
    ns.activeMutant = g.process.env.__STRYKER_ACTIVE_MUTANT__;
  }
  function retrieveNS() {
    return ns;
  }
  stryNS_9fa48 = retrieveNS;
  return retrieveNS();
}
stryNS_9fa48();
function stryCov_9fa48() {
  var ns = stryNS_9fa48();
  var cov = ns.mutantCoverage || (ns.mutantCoverage = {
    static: {},
    perTest: {}
  });
  function cover() {
    var c = cov.static;
    if (ns.currentTestId) {
      c = cov.perTest[ns.currentTestId] = cov.perTest[ns.currentTestId] || {};
    }
    var a = arguments;
    for (var i = 0; i < a.length; i++) {
      c[a[i]] = (c[a[i]] || 0) + 1;
    }
  }
  stryCov_9fa48 = cover;
  cover.apply(null, arguments);
}
function stryMutAct_9fa48(id) {
  var ns = stryNS_9fa48();
  function isActive(id) {
    if (ns.activeMutant === id) {
      if (ns.hitCount !== void 0 && ++ns.hitCount > ns.hitLimit) {
        throw new Error('Stryker: Hit count limit reached (' + ns.hitCount + ')');
      }
      return true;
    }
    return false;
  }
  stryMutAct_9fa48 = isActive;
  return isActive(id);
}
import { NicknameTooFewLettersError, NicknameTooLongError, NicknameTooShortError } from '../../errors/nickname';
export class Nickname {
  static readonly MINIMUM_LENGTH = 5;
  static readonly MAXIMUM_LENGTH = 20;
  static readonly MINIMUM_LETTERS_COUNT = 3;
  private constructor(public readonly value: string) {}
  static create(value: string) {
    if (stryMutAct_9fa48("0")) {
      {}
    } else {
      stryCov_9fa48("0");
      if (stryMutAct_9fa48("4") ? value.length >= Nickname.MINIMUM_LENGTH : stryMutAct_9fa48("3") ? value.length <= Nickname.MINIMUM_LENGTH : stryMutAct_9fa48("2") ? false : stryMutAct_9fa48("1") ? true : (stryCov_9fa48("1", "2", "3", "4"), value.length < Nickname.MINIMUM_LENGTH)) {
        if (stryMutAct_9fa48("5")) {
          {}
        } else {
          stryCov_9fa48("5");
          throw new NicknameTooShortError(value);
        }
      }
      if (stryMutAct_9fa48("9") ? value.length <= Nickname.MAXIMUM_LENGTH : stryMutAct_9fa48("8") ? value.length >= Nickname.MAXIMUM_LENGTH : stryMutAct_9fa48("7") ? false : stryMutAct_9fa48("6") ? true : (stryCov_9fa48("6", "7", "8", "9"), value.length > Nickname.MAXIMUM_LENGTH)) {
        if (stryMutAct_9fa48("10")) {
          {}
        } else {
          stryCov_9fa48("10");
          throw new NicknameTooLongError(value);
        }
      }
      const lettersOfNickname = stryMutAct_9fa48("11") ? value.match(/[a-zA-Z]/) && [] : (stryCov_9fa48("11"), value.match(stryMutAct_9fa48("12") ? /[^a-zA-Z]/ : (stryCov_9fa48("12"), /[a-zA-Z]/)) ?? (stryMutAct_9fa48("13") ? ["Stryker was here"] : (stryCov_9fa48("13"), [])));
      if (stryMutAct_9fa48("17") ? lettersOfNickname.length >= Nickname.MINIMUM_LETTERS_COUNT : stryMutAct_9fa48("16") ? lettersOfNickname.length <= Nickname.MINIMUM_LETTERS_COUNT : stryMutAct_9fa48("15") ? false : stryMutAct_9fa48("14") ? true : (stryCov_9fa48("14", "15", "16", "17"), lettersOfNickname.length < Nickname.MINIMUM_LETTERS_COUNT)) {
        if (stryMutAct_9fa48("18")) {
          {}
        } else {
          stryCov_9fa48("18");
          throw new NicknameTooFewLettersError(value);
        }
      }
      return new Nickname(value);
    }
  }
}