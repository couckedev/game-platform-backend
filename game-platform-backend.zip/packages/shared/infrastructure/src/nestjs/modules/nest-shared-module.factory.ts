import type { DynamicModule } from '@nestjs/common';
import { createSharedModule, type SharedModuleConfig } from '../../composition';
import { HttpAuthenticationGuard } from '../../http/common';
import { HealthcheckController } from '../controllers';
import { NestHttpAuthenticationGuard } from '../guards';
import { NestLogger } from '../services';
import { DatabaseClient, Logger } from '../tokens';
import { NestSharedModule } from './nest-shared.module';

export function createNestSharedModule(
  config: SharedModuleConfig,
): DynamicModule {
  const sharedModule = createSharedModule(config);

  return {
    module: NestSharedModule,
    providers: [
      { provide: Logger, useValue: sharedModule.logger },
      { provide: DatabaseClient, useValue: sharedModule.databaseClient },
      {
        provide: HttpAuthenticationGuard,
        useValue: sharedModule.httpAuthenticationGuard,
      },
      NestLogger,
      NestHttpAuthenticationGuard,
    ],
    controllers: [HealthcheckController],
    exports: [Logger, NestLogger, DatabaseClient, NestHttpAuthenticationGuard],
    global: true,
  };
}
