import {
  type CanActivate,
  type ExecutionContext,
  Inject,
  Injectable,
} from '@nestjs/common';
import {
  HttpAuthenticationGuard,
  type HttpAuthenticationGuard as HttpAuthenticationGuardType,
} from '../../http/common';

@Injectable()
export class NestHttpAuthenticationGuard implements CanActivate {
  constructor(
    @Inject(HttpAuthenticationGuard)
    private readonly httpAuthenticationGuard: HttpAuthenticationGuardType,
  ) {
    console.log(httpAuthenticationGuard);
  }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authorizationHeader: string = request.headers.authorization;
    console.log(this.httpAuthenticationGuard);
    await this.httpAuthenticationGuard.authenticate(authorizationHeader);
    return true;
  }
}
