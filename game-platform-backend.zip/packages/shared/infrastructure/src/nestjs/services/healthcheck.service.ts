import { Inject, Injectable } from '@nestjs/common';
import { sql } from 'drizzle-orm';
import type { DatabaseClient as DatabaseClientType } from '../../database/drizzle';
import { DatabaseClient } from '../tokens';

@Injectable()
export class HealthcheckService {
  constructor(
    @Inject(DatabaseClient)
    private readonly databaseClient: DatabaseClientType,
  ) {}

  async check(): Promise<void> {
    const isDatabaseHealthy = await this.checkDatabaseHealth();
    return { isDatabaseHealthy };
  }

  async checkDatabaseHealth(): Promise<boolean> {
    try {
      await this.databaseClient.execute(sql`SELECT 1`);
      return true;
    } catch {
      return false;
    }
  }
}
