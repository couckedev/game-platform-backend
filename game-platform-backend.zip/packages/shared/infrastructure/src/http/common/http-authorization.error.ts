export class HttpAuthorizationError extends Error {
  constructor() {
    super('Missing or invalid http request authorization header');
  }
}
