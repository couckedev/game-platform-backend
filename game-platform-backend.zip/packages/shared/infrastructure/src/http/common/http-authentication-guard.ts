import type { IdentityVerifier } from '../../authentication/common';
import { HttpAuthorizationError } from './http-authorization.error';

export class HttpAuthenticationGuard {
  constructor(private readonly identityVerifier: IdentityVerifier) {}

  async authenticate(authorizationToken: string): Promise<void> {
    if (
      authorizationToken.length === 0 ||
      !authorizationToken.startsWith('Bearer ')
    ) {
      throw new HttpAuthorizationError();
    }
    await this.identityVerifier.verify(authorizationToken);

    return;
  }
}
