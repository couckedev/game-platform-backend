import { describe, expect, it } from 'vitest';
import { IdentityVerificationFailedError } from '../../authentication/common';
import { InMemoryIdentityVerifier } from '../../authentication/in-memory';
import { HttpAuthenticationGuard } from './http-authentication-guard';
import { HttpAuthorizationError } from './http-authorization.error';

describe(HttpAuthenticationGuard, () => {
  it('rejects request if authorization header is empty', async () => {
    const authorizationHeader = '';
    const identityVerifier = new InMemoryIdentityVerifier();
    const httpAuthenticationGuard = new HttpAuthenticationGuard(
      identityVerifier,
    );

    const authentication = async () =>
      httpAuthenticationGuard.authenticate(authorizationHeader);

    await expect(authentication).rejects.toThrow(new HttpAuthorizationError());
  });

  it('rejects request if authorization header does not contain a valid bearer token', async () => {
    const authorizationHeader = 'invalid-bearer-token';
    const identityVerifier = new InMemoryIdentityVerifier();
    const httpAuthenticationGuard = new HttpAuthenticationGuard(
      identityVerifier,
    );

    const authentication = async () =>
      httpAuthenticationGuard.authenticate(authorizationHeader);

    await expect(authentication).rejects.toThrow(new HttpAuthorizationError());
  });

  it('rejects request if identity verification with bearer token has failed', async () => {
    const authorizationHeader = 'Bearer valid-bearer-token';
    const identityVerifier = new InMemoryIdentityVerifier();
    identityVerifier.verificationResult = new IdentityVerificationFailedError();
    const httpAuthenticationGuard = new HttpAuthenticationGuard(
      identityVerifier,
    );

    const authentication = async () =>
      httpAuthenticationGuard.authenticate(authorizationHeader);

    await expect(authentication).rejects.toThrow(
      new IdentityVerificationFailedError(),
    );
  });
});
