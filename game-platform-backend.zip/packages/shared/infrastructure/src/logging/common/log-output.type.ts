export type LogOutput = 'stdout';
