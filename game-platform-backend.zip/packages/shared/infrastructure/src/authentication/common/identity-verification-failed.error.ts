export class IdentityVerificationFailedError extends Error {
  constructor() {
    super('Identity verification failed');
  }
}
