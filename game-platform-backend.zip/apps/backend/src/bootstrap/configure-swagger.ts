import fastifySwagger from '@fastify/swagger';
import fastifySwaggerUi from '@fastify/swagger-ui';
import type { NestFastifyApplication } from '@nestjs/platform-fastify';
import { playerModuleRegistry } from '@player/infrastructure/openapi';
import {
  generateOpenAPI,
  sharedModuleRegistry,
} from '@shared/infrastructure/openapi';
import type { OpenAPIV3_1 } from 'openapi-types';
import type { AppConfig } from '../app/configuration';

export async function configureSwagger(
  app: NestFastifyApplication,
  config: AppConfig,
): Promise<void> {
  const document = generateOpenAPI(
    [sharedModuleRegistry, playerModuleRegistry],
    {
      authorizationUrl: config.authentication.authorizationUrl,
      tokenUrl: config.authentication.tokenUrl,
    },
  );

  await app.register(fastifySwagger, {
    transformObject: () => document as unknown as OpenAPIV3_1.Document,
  });

  await app.register(fastifySwaggerUi, {
    routePrefix: '/api',
    initOAuth: {
      usePkceWithAuthorizationCodeGrant: true,
      clientId: 'game-platform-backend-swagger',
    },
    uiConfig: {
      persistAuthorization: true,
      oauth2RedirectUrl: `${config.backend.host}:${config.backend.port}/api/oauth2-redirect.html`,
    },
  });
}
