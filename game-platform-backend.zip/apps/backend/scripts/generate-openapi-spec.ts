import { writeFileSync } from 'node:fs';
import { playerModuleRegistry } from '@player/infrastructure/openapi';
import {
  generateOpenAPI,
  sharedModuleRegistry,
} from '@shared/infrastructure/openapi';
import { parseAppConfig } from '../src/app/configuration';

const parsedEnv = parseAppConfig(process.env);
const document = generateOpenAPI([sharedModuleRegistry, playerModuleRegistry], {
  authorizationUrl: parsedEnv.authentication.authorizationUrl,
  tokenUrl: parsedEnv.authentication.tokenUrl,
});

writeFileSync('openapi.json', JSON.stringify(document, null, 2));
